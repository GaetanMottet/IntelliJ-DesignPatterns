package DigitalAndAnalogClocks;

public interface Observer {
    void update();
}
