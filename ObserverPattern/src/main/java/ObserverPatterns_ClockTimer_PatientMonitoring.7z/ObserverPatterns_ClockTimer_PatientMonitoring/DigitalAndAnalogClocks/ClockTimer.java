package DigitalAndAnalogClocks;

public interface ClockTimer {
    public int getHour();
    public int getMinute();
    public int getSecond();
    public void tick();

    public void registerObserver(Observer o) ;
    public void removeObserver(Observer o) ;


}
