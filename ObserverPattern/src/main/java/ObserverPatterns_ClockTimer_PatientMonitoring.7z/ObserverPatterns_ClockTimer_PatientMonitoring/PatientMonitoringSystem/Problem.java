package PatientMonitoringSystem;

public enum Problem {
    NO_PROBLEM,
    BLOOD_PRESSURE,
    OXYMETRIE;

}
