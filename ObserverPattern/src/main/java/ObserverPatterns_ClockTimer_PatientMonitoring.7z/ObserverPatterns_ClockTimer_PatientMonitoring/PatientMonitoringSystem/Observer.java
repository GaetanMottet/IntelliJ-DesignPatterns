package PatientMonitoringSystem;

public interface Observer {
    void update(Problem pb);
}
