package SortingStrategies;

public interface SortStrat {
    public void sort(int[] vect);
}
